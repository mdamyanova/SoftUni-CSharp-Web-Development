﻿namespace _08.MilitaryElite.Interfaces
{
    public interface IMission
    {
        string Name { get; }

        string State { get; }
    }
}