﻿namespace _08.MilitaryElite.Interfaces
{
    public interface IRepair
    {
        string Name { get; }

        int Hours { get; }
    }
}