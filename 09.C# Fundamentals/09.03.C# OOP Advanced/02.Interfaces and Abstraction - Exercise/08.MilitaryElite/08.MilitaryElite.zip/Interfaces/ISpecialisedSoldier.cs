﻿namespace _08.MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}