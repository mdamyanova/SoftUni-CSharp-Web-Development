﻿namespace _08.MilitaryElite.Interfaces
{
    public class ISpy
    {
        int CodeNumber { get; }
    }
}