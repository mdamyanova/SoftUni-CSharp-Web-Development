﻿using System;
using System.Runtime.InteropServices;
using NUnit.Framework;

public class AxeTests
{
    [Test]
    public void AxeLosesDurabilyAfterAttack()
    {
        //Arrange
        var axe = new Axe(10, 10);
        var dummy = new Dummy(10, 10);

        //Act
        axe.Attack(dummy);

        //Assert
        Assert.AreEqual(9, axe.DurabilityPoints, "Axe Durability doesn't change after attack");
    }

    [Test]
    public void BrokenAxeCantAttack()
    {
        //Arrange
        var axe = new Axe(1, 1);
        var dummy = new Dummy(10, 10);

        //Act
        axe.Attack(dummy);

        //Assert
        var ex = Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
        Assert.That(ex.Message, Is.EqualTo("Axe is broken."));
    }
}