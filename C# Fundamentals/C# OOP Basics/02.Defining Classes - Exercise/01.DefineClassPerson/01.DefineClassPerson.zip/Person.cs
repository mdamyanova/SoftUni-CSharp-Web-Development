﻿ public class Person
 {
     public int age;
     public string name;
 }