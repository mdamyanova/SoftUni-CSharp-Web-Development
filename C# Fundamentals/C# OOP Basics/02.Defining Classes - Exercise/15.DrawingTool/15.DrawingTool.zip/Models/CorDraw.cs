﻿namespace _15.DrawingTool.Models
{
    public class CorDraw
    {
        public string Figure { get; set; }
    }
}